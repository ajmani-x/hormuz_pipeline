"""
Synthetic stand-ins for live data feeds, plus static reference data describing
an illustrative Indian refinery / crude supply network.

IMPORTANT: The reference numbers here (capacities, dependencies, reserve
volumes) are illustrative placeholders for demo purposes, NOT sourced from a
live dataset. To make this a real system, swap the functions in this file for
real integrations:

  - generate_news_signals()   -> news/geopolitics API + NLP sentiment model
  - generate_ais_signals()    -> AIS tanker tracking provider (e.g. Kpler, MarineTraffic)
  - generate_market_signals() -> market data provider (e.g. Refinitiv, Platts)
  - REFINERIES / SUPPLIERS / SPR_SITES -> internal ERP / national statistics

Everything downstream (agents/, orchestrator.py) only depends on the
dataclass shapes in models.py, so swapping the data layer does not require
touching agent logic.
"""
import random

from .models import NewsSignal, AISSignal, MarketSignal, CrudeGrade, Supplier, Refinery, SPRSite

ROUTES = [
    "Hormuz-Gujarat",
    "Hormuz-Kochi",
    "Hormuz-Mumbai",
    "CapeRoute-EastCoast",
    "RedSea-WestCoast",
]

# --- Crude grades -----------------------------------------------------------

ARAB_LIGHT = CrudeGrade("Arab Light", api_gravity=33.0, sulfur_pct=1.8)
UPPER_ZAKUM = CrudeGrade("Upper Zakum", api_gravity=34.0, sulfur_pct=1.7)
BASRA_LIGHT = CrudeGrade("Basra Light", api_gravity=30.0, sulfur_pct=2.5)
URALS = CrudeGrade("Urals", api_gravity=31.0, sulfur_pct=1.5)
WTI = CrudeGrade("WTI Midland", api_gravity=40.0, sulfur_pct=0.4)
BONNY_LIGHT = CrudeGrade("Bonny Light", api_gravity=35.0, sulfur_pct=0.2)

# --- Suppliers (route + lead time determine substitutability) --------------

SUPPLIERS = [
    Supplier("Saudi Aramco", "Saudi Arabia", "Hormuz-Gujarat", ARAB_LIGHT, 300_000, 10, True),
    Supplier("ADNOC", "UAE", "Hormuz-Kochi", UPPER_ZAKUM, 200_000, 9, True),
    Supplier("Iraq SOMO", "Iraq", "Hormuz-Mumbai", BASRA_LIGHT, 150_000, 11, True),
    Supplier("Rosneft", "Russia", "CapeRoute-EastCoast", URALS, 400_000, 21, False),
    Supplier("US Gulf Exporters", "USA", "CapeRoute-EastCoast", WTI, 150_000, 24, False),
    Supplier("NNPC", "Nigeria", "RedSea-WestCoast", BONNY_LIGHT, 100_000, 18, False),
]

# --- Refineries --------------------------------------------------------------

REFINERIES = [
    Refinery(
        "Reliance Jamnagar", "Gujarat", 1_240_000, "Hormuz-Gujarat",
        compatible_api_range=(28.0, 42.0), compatible_sulfur_max=3.0,
        current_suppliers=["Saudi Aramco"],
    ),
    Refinery(
        "Nayara Vadinar", "Gujarat", 400_000, "Hormuz-Gujarat",
        compatible_api_range=(30.0, 36.0), compatible_sulfur_max=2.0,
        current_suppliers=["Saudi Aramco"],
    ),
    Refinery(
        "BPCL Kochi", "Kerala", 310_000, "Hormuz-Kochi",
        compatible_api_range=(30.0, 36.0), compatible_sulfur_max=2.0,
        current_suppliers=["ADNOC"],
    ),
    Refinery(
        "HPCL Mumbai", "Maharashtra", 190_000, "Hormuz-Mumbai",
        compatible_api_range=(28.0, 38.0), compatible_sulfur_max=2.6,
        current_suppliers=["Iraq SOMO"],
    ),
    Refinery(
        "IOC Paradip", "Odisha", 300_000, "CapeRoute-EastCoast",
        compatible_api_range=(28.0, 42.0), compatible_sulfur_max=2.0,
        current_suppliers=["Rosneft"],
    ),
]

NATIONAL_DEMAND_BBL_PER_DAY = 5_000_000  # illustrative

# --- Strategic Petroleum Reserve sites --------------------------------------

SPR_SITES = [
    SPRSite("Vizag", "Andhra Pradesh", capacity_mmbbl=9.9, current_fill_mmbbl=9.0,
            max_draw_rate_bbl_per_day=120_000, serves_refineries=["HPCL Mumbai", "IOC Paradip"]),
    SPRSite("Mangalore", "Karnataka", capacity_mmbbl=11.3, current_fill_mmbbl=10.0,
            max_draw_rate_bbl_per_day=150_000, serves_refineries=["BPCL Kochi", "Reliance Jamnagar"]),
    SPRSite("Padur", "Karnataka", capacity_mmbbl=18.3, current_fill_mmbbl=16.0,
            max_draw_rate_bbl_per_day=180_000, serves_refineries=["Reliance Jamnagar", "Nayara Vadinar"]),
]


# ---------------------------------------------------------------------------
# Synthetic live-feed generators
# ---------------------------------------------------------------------------

def generate_news_signals(seed: int = None) -> list:
    rng = random.Random(seed)
    headlines = [
        ("Iran-linked forces seize tanker near Strait of Hormuz", "Reuters", -0.8),
        ("Gulf states hold naval exercises amid rising tension", "AP", -0.5),
        ("Sanctions tighten on Iranian oil exports", "Bloomberg", -0.6),
        ("Diplomatic talks aim to de-escalate Gulf tensions", "AFP", 0.4),
        ("Insurance premiums for Hormuz transits spike", "Lloyd's List", -0.7),
    ]
    signals = []
    for headline, source, base_sentiment in headlines:
        signals.append(NewsSignal(
            headline=headline,
            source=source,
            sentiment=base_sentiment + rng.uniform(-0.1, 0.1),
            relevance=rng.uniform(0.7, 1.0),
            region="Strait of Hormuz",
        ))
    return signals


def generate_ais_signals(seed: int = None) -> list:
    rng = random.Random(seed)
    signals = []
    for route in ROUTES:
        is_hormuz = route.startswith("Hormuz")
        normal = rng.randint(15, 25)
        drop = rng.uniform(0.3, 0.6) if is_hormuz else rng.uniform(0.0, 0.05)
        current = int(normal * (1 - drop))
        signals.append(AISSignal(
            route=route,
            tanker_count_normal=normal,
            tanker_count_current=current,
            avg_transit_delay_hours=rng.uniform(20, 60) if is_hormuz else rng.uniform(0, 5),
            port_congestion_index=rng.uniform(0.5, 0.9) if is_hormuz else rng.uniform(0.1, 0.3),
        ))
    return signals


def generate_market_signals(seed: int = None) -> list:
    rng = random.Random(seed)
    return [
        MarketSignal("Brent", price_usd_bbl=rng.uniform(85, 105), price_change_pct_7d=rng.uniform(5, 18),
                     freight_rate_index=rng.uniform(1.2, 1.8)),
        MarketSignal("Dubai", price_usd_bbl=rng.uniform(83, 103), price_change_pct_7d=rng.uniform(5, 18),
                     freight_rate_index=rng.uniform(1.3, 2.0)),
    ]
